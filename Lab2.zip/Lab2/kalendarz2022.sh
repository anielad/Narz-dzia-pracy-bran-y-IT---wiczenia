#!/bin/bash

if [[ $# -lt 2 ]]; then
    echo "Podaj numer dnia i miesiąc jako argumenty."
    exit 1
fi

day=$1
month=$2

day_name=$(date -d "2022-$month-$day" +%A 2>/dev/null)
if [[ -z $day_name ]]; then
    echo "Nieprawidłowy dzień lub miesiąc." >> plik2.txt
    exit 1
fi

echo "Dzień tygodnia: $day_name"
echo "Dzień tygodnia: $day_name" >> plik1.txt
