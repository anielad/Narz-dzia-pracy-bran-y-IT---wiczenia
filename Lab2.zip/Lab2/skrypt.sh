#!/bin/bash

function silnia_rek {
  if [[ $1 -le 1 ]]; then
    echo 1
  else
    echo $(( $1 * $(silnia_rek $(( $1 - 1 ))) ))
  fi
}

function silnia_iter {
  local wynik=1
  for (( i=1; i<=$1; i++ )); do
    wynik=$(( $wynik * $i ))
  done
  echo $wynik
}

if [[ $# -lt 4 ]]; then
  echo "Podaj wszystkie wymagane argumenty:"
  read -p "Imię: " imie
  read -p "Nazwisko: " nazwisko
  read -p "Rok urodzenia: " rok
  read -p "nazwa pliku " plik
else
  imie=$1
  nazwisko=$2
  rok=$3
  plik=$4
fi

aktualny_rok=$(date +%Y)
wiek=$(( $aktualny_rok - $rok ))
echo "Witaj $imie $nazwisko! Masz $wiek lat."

silnia_rek=$(silnia_rek $wiek)
silnia_iter=$(silnia_iter $wiek)
echo "$imie, $nazwisko, $rok, $wiek, $silnia_rek, $silnia_iter" >> $plik
