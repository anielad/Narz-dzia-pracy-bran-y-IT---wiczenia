#!/bin/bash

if [ $# -eq 0 ]; then
    read -p "Podaj nazwę pliku: " plik
else
    plik=$1
fi

if [ ! -e "$plik" ]; then
    echo "Plik $plik nie istnieje!"
    exit 1
fi

if ! echo "$PATH" | grep -q "$PWD"; then
    echo "Dodaję $PWD do PATH..."
    export PATH="$PWD:$PATH"
fi

nowy_katalog="daneUsera_$(date +%Y%m%d_%H%M%S)"
mkdir "$nowy_katalog"
mv "$plik" "$nowy_katalog/$plik"

ls -al
ls -al > "$nowy_katalog/$plik"

echo "Wyniki zapisano w $nowy_katalog/$plik"
